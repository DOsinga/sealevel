unit fEurope;

interface

uses
    Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
    uTool, StdCtrls, JPeg;

const
{    kMaxX = 360*12;  // Arraysize of heights
    kMaxY = 179*12;  // Arraysize of heights}
    kMaxX = 1024;
    kMaxY = 768;

type
    THeights = array[0..kMaxX-1,0..kMaxY-1] of SmallInt;
//    THeightsEurope = array[0..1023,0..767] of SmallInt;
    TByteArray = array[0..kMaxX-1] of Byte;

    TfrmMain = class(TForm)
    sbLevel: TScrollBar;
    SaveDialog1: TSaveDialog;
    procedure FormCreate(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure FormPaint(Sender: TObject);
    procedure sbLevelChange(Sender: TObject);
      private
        { Private declarations }
        BM : TBitmap;
        Heights : THeights;
        Zoom : Double;
        function GetHeight(X,Y : Integer ) : Integer;
        procedure DrawMap;
        procedure SetPixels( ALevel : Integer );
        procedure SetLevel( ALevel : Integer );
      public
        { Public declarations }
        FSeaLevel : Integer;
    end;

var
  frmMain: TfrmMain;

implementation

{$R *.DFM}

function CreateMapPalette : HPalette;
var
   PalSize: Integer;
   Palette: PLogPalette;
   I : Integer;

Procedure SetColor( Palette: PLogPalette;
                      iStart, iEnd : Integer;
                      sR,sG,sB : Integer;
                      eR,eG,eB : Integer );
var
   I : Integer;
begin
    if iStart=iEnd then with Palette^ do begin
        palPalEntry[iStart].peRed   := sR;
        palPalEntry[iStart].peGreen := sG;
        palPalEntry[iStart].peBlue  := sB;
        palPalEntry[iStart].peFlags := 0;
        Exit;
    end;
    for I := iStart to iEnd do with Palette^ do begin
        palPalEntry[I].peRed := Round(WeighAverage((I-iStart)/(iEnd-iStart),eR,sR));
        palPalEntry[I].peGreen := Round(WeighAverage((I-iStart)/(iEnd-iStart),eG,sG));
        palPalEntry[I].peBlue := Round(WeighAverage((I-iStart)/(iEnd-iStart),eB,sB));
        palPalEntry[I].peFlags := 0;
    end;
end;

begin
     //Allocate Memory for Palette
     PalSize := SizeOf(TLogPalette) + (256 * SizeOf(TPaletteEntry));
     Palette := AllocMem(PalSize);

     //Fill in structure
     with Palette^ do
     begin
          palVersion := $300;
          palNumEntries := 256;
          SetColor( Palette, 11,11,     52,20,182,  52,20,182 );     // Dark Blue
          SetColor( Palette, 12,12,     52,47,229,  52,47,229 );     // Slightly lighter
          SetColor( Palette, 13,13,     201,147,20,  201,147,20 );   // Yellow-ish
          SetColor( Palette, 14,14,     122,147,20,  122,147,20 );   // Yellow-ish
          SetColor( Palette, 15,15,     255,128,128,  255,128,128 );   // Marker
          SetColor( Palette, 20,130,    52,47,229,  128,128,255 );   // lighter blue
          SetColor( Palette, 131,240,   75,202,57, 122,147,20);
     end;

     Result := CreatePalette(Palette^);
     FreeMem(Palette, PalSize);
end;


procedure TfrmMain.DrawMap;
begin
    StretchBlt( Canvas.Handle, 0,0, ClientWidth, ClientHeight,
                BM.Canvas.Handle, 0,0, kMaxX,kMaxY, SRCCOPY );

end;

procedure TfrmMain.FormCreate(Sender: TObject);
var
    F : file of THeights;
    H, X,Y : Integer;
begin
    AssignFile( F, 'europe.int' );
    Reset( F);
    Read( F, Heights );
    CloseFile( F );

    BM := TBitmap.Create;
    BM.HandleType := bmDIB;
    BM.PixelFormat := pf8Bit;
    BM.Width := kMaxX;
    BM.Height := kMaxY;
    BM.Palette := CreateMapPalette;

    SetPixels( FSeaLevel );

    DrawMap;

    Zoom := 1.0;
end;

procedure TfrmMain.SetPixels( ALevel : Integer );
var
    H, X,Y : Integer;
    Line : ^TByteArray;
begin
    for Y := 0 to kMaxY-1 do begin
        Line := BM.ScanLine[Y];
        for X := 0 to kMaxX-1 do begin
            H := GetHeight(X,Y);
            if H < (- 2500+ALevel) then
                Line^[X]:=11
            else if H < (-500+ALevel) then
                Line^[X]:=12
            else if H > (1500+ALevel) then
                Line^[X]:=13
            else if H > (500+ALevel) then
                Line^[X]:=14
            else
                Line^[X]:=Round( 20 + 220*(H+500-ALevel)/1000 );
        end;
    end;
    BM.Canvas.TextOut( 0, BM.Height-BM.Canvas.TextHeight('Douwe'), ' (c) Douwe Osinga 2003. Released under GPL. see gpl.txt' );
end;

function TfrmMain.GetHeight(X, Y: Integer): Integer;
begin
    Result := Heights[X,Y];
    Exit;
    X := X - (kMaxX div 2);
    if X <0 then
       X := X + kMaxX;
    Result := Heights[Y,X];
end;

procedure TfrmMain.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
var
    JPeg : TJpegImage;
    Small : TBitmap;
    W,H : Integer;
begin
    if Key=Ord('A') then
        Inc(FSeaLevel,20)
    else if Key=Ord('Z') then
        Dec(FSeaLevel,20);
    SetLevel( FSeaLevel );
    if Key=32 then begin
        if not SaveDialog1.Execute then Exit;
        Small := TBitmap.Create;
        Small.Assign( BM );
        Small.PixelFormat := pf24bit;
        W := BM.Width div 3;
        H := BM.Height div 3;
        SetStretchBltMode(Small.Canvas.Handle, STRETCH_DELETESCANS);
        StretchBlt( Small.Canvas.Handle, 0,0, W,H,
                    Small.Canvas.Handle, 0,0, BM.Width, BM.Height, SRCCOPY );
        Small.Width := W;
        Small.Height := H;
        JPeg := TJpegImage.Create;
        JPeg.Assign( Small );
        JPeg.SaveToFile( SaveDialog1.FileName );
        JPeg.Free;
        Small.Free;
    end;
end;

procedure TfrmMain.FormPaint(Sender: TObject);
begin
    SetLevel( FSeaLevel );
end;

procedure TfrmMain.SetLevel(ALevel: Integer);
begin
    FSeaLevel := ALevel;
    SetPixels( FSeaLevel );
    Caption := 'Europe seat at ' + IntToStr(ALevel) + ' meters.';
    DrawMap;
end;

procedure TfrmMain.sbLevelChange(Sender: TObject);
begin
    SetLevel( sbLevel.Position );
end;

end.
