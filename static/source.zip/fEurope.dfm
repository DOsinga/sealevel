object frmMain: TfrmMain
  Left = 120
  Top = 56
  Width = 1032
  Height = 795
  Caption = 'Europe'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  OnCreate = FormCreate
  OnKeyDown = FormKeyDown
  OnPaint = FormPaint
  PixelsPerInch = 96
  TextHeight = 13
  object sbLevel: TScrollBar
    Left = 1008
    Top = 0
    Width = 16
    Height = 768
    Align = alRight
    Kind = sbVertical
    Max = 250
    Min = -250
    PageSize = 0
    TabOrder = 0
    OnChange = sbLevelChange
  end
  object SaveDialog1: TSaveDialog
    DefaultExt = 'jpg'
    Filter = 'Jpeg|jpg'
    InitialDir = 'C:\tmp'
    Left = 120
    Top = 136
  end
end
